const { PubSub } = require('@google-cloud/pubsub');
const pubSubClient = new PubSub();
const subscriptionName = "projects/terraform-pekao/subscriptions/subscription-kuba";

exports.retrieveMessage = async (req, res) => {
  try {
    const subscription = pubSubClient.subscription(subscriptionName);
    let messagesReceived = [];

    // Set up message event listener
    const messageHandler = (message) => {
      messagesReceived.push(message.data.toString());
      message.ack(); // Acknowledge message
    };

    // Register the event listener
    subscription.on('message', messageHandler);

    // Wait briefly for messages
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Remove event listener to prevent multiple responses
    subscription.removeListener('message', messageHandler);

    // Send response once, after waiting
    if (messagesReceived.length === 0) {
      return res.status(404).json({ message: 'No messages available' });
    }

    return res.status(200).json({ messages: messagesReceived });

  } catch (error) {
    console.error('Error retrieving message:', error);
    
    // Ensure only one response is sent
    if (!res.headersSent) {
      return res.status(500).json({ error: 'Failed to retrieve message' });
    }
  }
};
